﻿namespace picture
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.mainMenu1 = new System.Windows.Forms.MainMenu(this.components);
            this.doc = new System.Windows.Forms.MenuItem();
            this.open = new System.Windows.Forms.MenuItem();
            this.save = new System.Windows.Forms.MenuItem();
            this.reset = new System.Windows.Forms.MenuItem();
            this.pic_operate = new System.Windows.Forms.MenuItem();
            this.translation = new System.Windows.Forms.MenuItem();
            this.acoustic_pic = new System.Windows.Forms.MenuItem();
            this.scale = new System.Windows.Forms.MenuItem();
            this.revolve = new System.Windows.Forms.MenuItem();
            this.image_operate = new System.Windows.Forms.MenuItem();
            this.pseudo_color = new System.Windows.Forms.MenuItem();
            this.smooth = new System.Windows.Forms.MenuItem();
            this.sharpening = new System.Windows.Forms.MenuItem();
            this.edge = new System.Windows.Forms.MenuItem();
            this.Roberts算子 = new System.Windows.Forms.MenuItem();
            this.Perwit算子 = new System.Windows.Forms.MenuItem();
            this.Sobel算子 = new System.Windows.Forms.MenuItem();
            this.apart = new System.Windows.Forms.MenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.skinEngine1 = new Sunisoft.IrisSkin.SkinEngine();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.doc,
            this.pic_operate,
            this.image_operate});
            // 
            // doc
            // 
            this.doc.Index = 0;
            this.doc.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.open,
            this.save,
            this.reset});
            this.doc.Text = "文件";
            // 
            // open
            // 
            this.open.Index = 0;
            this.open.Text = "打开";
            this.open.Click += new System.EventHandler(this.menuItem2_Click);
            // 
            // save
            // 
            this.save.Index = 1;
            this.save.Text = "保存";
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // reset
            // 
            this.reset.Index = 2;
            this.reset.Text = "重置";
            this.reset.Click += new System.EventHandler(this.reset_Click);
            // 
            // pic_operate
            // 
            this.pic_operate.Index = 1;
            this.pic_operate.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.translation,
            this.acoustic_pic,
            this.scale,
            this.revolve});
            this.pic_operate.Text = "图像几何变换";
            // 
            // translation
            // 
            this.translation.Index = 0;
            this.translation.Text = "平移";
            this.translation.Click += new System.EventHandler(this.translation_Click);
            // 
            // acoustic_pic
            // 
            this.acoustic_pic.Index = 1;
            this.acoustic_pic.Text = "镜像";
            this.acoustic_pic.Click += new System.EventHandler(this.acoustic_pic_Click);
            // 
            // scale
            // 
            this.scale.Index = 2;
            this.scale.Text = "缩放";
            this.scale.Click += new System.EventHandler(this.scale_Click);
            // 
            // revolve
            // 
            this.revolve.Index = 3;
            this.revolve.Text = "旋转";
            this.revolve.Click += new System.EventHandler(this.revolve_Click);
            // 
            // image_operate
            // 
            this.image_operate.Index = 2;
            this.image_operate.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.pseudo_color,
            this.smooth,
            this.sharpening,
            this.edge,
            this.apart});
            this.image_operate.Text = "彩色图像处理";
            // 
            // pseudo_color
            // 
            this.pseudo_color.Index = 0;
            this.pseudo_color.Text = "伪彩色处理";
            this.pseudo_color.Click += new System.EventHandler(this.pseudo_color_Click);
            // 
            // smooth
            // 
            this.smooth.Index = 1;
            this.smooth.Text = "平滑处理";
            this.smooth.Click += new System.EventHandler(this.smooth_Click);
            // 
            // sharpening
            // 
            this.sharpening.Index = 2;
            this.sharpening.Text = "锐化处理";
            this.sharpening.Click += new System.EventHandler(this.sharpening_Click);
            // 
            // edge
            // 
            this.edge.Index = 3;
            this.edge.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.Roberts算子,
            this.Perwit算子,
            this.Sobel算子});
            this.edge.Text = "边缘检测";
            // 
            // Roberts算子
            // 
            this.Roberts算子.Index = 0;
            this.Roberts算子.Text = "Roberts算子";
            this.Roberts算子.Click += new System.EventHandler(this.Roberts算子_Click);
            // 
            // Perwit算子
            // 
            this.Perwit算子.Index = 1;
            this.Perwit算子.Text = "Prewit算子";
            this.Perwit算子.Click += new System.EventHandler(this.Perwit算子_Click);
            // 
            // Sobel算子
            // 
            this.Sobel算子.Index = 2;
            this.Sobel算子.Text = "Sobel算子";
            this.Sobel算子.Click += new System.EventHandler(this.Sobel算子_Click);
            // 
            // apart
            // 
            this.apart.Index = 4;
            this.apart.Text = "图像分割";
            this.apart.Click += new System.EventHandler(this.apart_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(237, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(520, 439);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.Image = global::picture.Properties.Resources._1__1_;
            this.label1.Location = new System.Drawing.Point(12, 374);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(199, 89);
            this.label1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Image = global::picture.Properties.Resources._5_140FGZS0;
            this.label2.Location = new System.Drawing.Point(52, 218);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 121);
            this.label2.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.Image = global::picture.Properties.Resources._5_140FGZ247_52;
            this.label3.Location = new System.Drawing.Point(12, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 81);
            this.label3.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.Image = global::picture.Properties.Resources._5_140FGZ247_52;
            this.label4.Location = new System.Drawing.Point(126, 67);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 87);
            this.label4.TabIndex = 4;
            // 
            // skinEngine1
            // 
            this.skinEngine1.@__DrawButtonFocusRectangle = true;
            this.skinEngine1.DisabledButtonTextColor = System.Drawing.Color.Gray;
            this.skinEngine1.DisabledMenuFontColor = System.Drawing.SystemColors.GrayText;
            this.skinEngine1.InactiveCaptionColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.skinEngine1.SerialNumber = "";
            this.skinEngine1.SkinFile = null;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(779, 497);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Menu = this.mainMenu1;
            this.Name = "Form1";
            this.Text = "毕业设计-杨浩";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.MainMenu mainMenu1;
        private System.Windows.Forms.MenuItem doc;
        private System.Windows.Forms.MenuItem open;
        private System.Windows.Forms.MenuItem pic_operate;
        private System.Windows.Forms.MenuItem translation;
        private System.Windows.Forms.MenuItem acoustic_pic;
        private System.Windows.Forms.MenuItem scale;
        private System.Windows.Forms.MenuItem revolve;
        private System.Windows.Forms.MenuItem image_operate;
        private System.Windows.Forms.MenuItem pseudo_color;
        private System.Windows.Forms.MenuItem smooth;
        private System.Windows.Forms.MenuItem sharpening;
        private System.Windows.Forms.MenuItem edge;
        private System.Windows.Forms.MenuItem apart;
        private System.Windows.Forms.MenuItem save;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuItem reset;
        private System.Windows.Forms.MenuItem Roberts算子;
        private System.Windows.Forms.MenuItem Perwit算子;
        private System.Windows.Forms.MenuItem Sobel算子;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private Sunisoft.IrisSkin.SkinEngine skinEngine1;
    }
}


﻿namespace picture
{
    partial class pColor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.intSeg = new System.Windows.Forms.RadioButton();
            this.gcTrans = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.intNum = new System.Windows.Forms.ComboBox();
            this.start = new System.Windows.Forms.Button();
            this.close = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.intNum);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.gcTrans);
            this.groupBox1.Controls.Add(this.intSeg);
            this.groupBox1.Location = new System.Drawing.Point(44, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(292, 142);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "伪彩色处理方法";
            // 
            // intSeg
            // 
            this.intSeg.AutoSize = true;
            this.intSeg.Checked = true;
            this.intSeg.Location = new System.Drawing.Point(34, 37);
            this.intSeg.Name = "intSeg";
            this.intSeg.Size = new System.Drawing.Size(83, 16);
            this.intSeg.TabIndex = 0;
            this.intSeg.TabStop = true;
            this.intSeg.Text = "强度分层法";
            this.intSeg.UseVisualStyleBackColor = true;
            this.intSeg.CheckedChanged += new System.EventHandler(this.intSeg_CheckedChanged);
            // 
            // gcTrans
            // 
            this.gcTrans.AutoSize = true;
            this.gcTrans.Location = new System.Drawing.Point(34, 89);
            this.gcTrans.Name = "gcTrans";
            this.gcTrans.Size = new System.Drawing.Size(125, 16);
            this.gcTrans.TabIndex = 1;
            this.gcTrans.Text = "灰度级-彩色变换法";
            this.gcTrans.UseVisualStyleBackColor = true;
            this.gcTrans.CheckedChanged += new System.EventHandler(this.gcTrans_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(144, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "分层数：";
            // 
            // intNum
            // 
            this.intNum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.intNum.FormattingEnabled = true;
            this.intNum.Items.AddRange(new object[] {
            "分4层",
            "分8层",
            "分16层",
            "分32层"});
            this.intNum.Location = new System.Drawing.Point(203, 36);
            this.intNum.Name = "intNum";
            this.intNum.Size = new System.Drawing.Size(71, 20);
            this.intNum.TabIndex = 3;
            this.intNum.SelectedIndex = 0;
            
            // 
            // start
            // 
            this.start.Location = new System.Drawing.Point(66, 192);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(75, 23);
            this.start.TabIndex = 1;
            this.start.Text = "确定";
            this.start.UseVisualStyleBackColor = true;
            this.start.Click += new System.EventHandler(this.start_Click);
            // 
            // close
            // 
            this.close.Location = new System.Drawing.Point(243, 192);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(75, 23);
            this.close.TabIndex = 2;
            this.close.Text = "退出";
            this.close.UseVisualStyleBackColor = true;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // pColor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(387, 243);
            this.ControlBox = false;
            this.Controls.Add(this.close);
            this.Controls.Add(this.start);
            this.Controls.Add(this.groupBox1);
            this.Name = "pColor";
            this.Text = "伪彩色处理";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox intNum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton gcTrans;
        private System.Windows.Forms.RadioButton intSeg;
        private System.Windows.Forms.Button start;
        private System.Windows.Forms.Button close;
    }
}
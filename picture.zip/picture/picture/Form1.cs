﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace picture
{
    public partial class Form1 : Form
    {
        private string curFileName;
        private Bitmap curBitmap;
        private Bitmap dstmap;

        public Form1()
        {
            InitializeComponent();
            this.skinEngine1 = new Sunisoft.IrisSkin.SkinEngine(((System.ComponentModel.Component)(this)));
            this.skinEngine1.SkinFile = Application.StartupPath + "//vista1_green.ssk";

        }

        //打开图片操作
        private void menuItem2_Click(object sender, EventArgs e)
        {
            //创建OpenFile
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "所有图像文件|*.bmp;*.pcx;*.png;*.jpg;*.gif;" +
                "*.tif;*.ico;*.dxf;*.cgm;*.cdr;*.wmf;*.eps;*.emf|" +
                "位图(*.bmp;*.jpg;*.png;...)|*.bmp;*.pcx;*.png;*.jpg;*.gif;*.tif;*.ico|" +
                "矢量图(*.wmf;*.eps;*.emf;..)|*.dxf;*.cgm;*.cdr;*.wmf;*.eps;*.emf";
            //设置对话框标题
            open.Title = "打开图像文件";
            open.CheckFileExists = true;
            open.CheckPathExists = true;
            open.Multiselect = false;
            if (open.ShowDialog() == DialogResult.OK)
            {
                curFileName = open.FileName;
                try
                {
                    curBitmap = (Bitmap)Image.FromFile(curFileName);
                }
                catch (Exception exp)
                {
                    MessageBox.Show(exp.Message);
                }

            }
            else if (curBitmap == null)
            {
                MessageBox.Show("你没有选择图片", "信息提示");
            }

            this.pictureBox1.Image = curBitmap;

            Invalidate();
        }


        //保存图片操作
        private void save_Click(object sender, EventArgs e)
        {
            if (curBitmap != null)
            {
                SaveFileDialog save = new SaveFileDialog();
                save.Title = "图片保存";
                save.Filter = @"jpeg|*.jpg|bmp|*.bmp";
                save.ShowHelp = true;
                if (save.ShowDialog() == DialogResult.OK)
                {
                    string fileName = save.FileName;
                    string strfileExtn = fileName.Remove(0, fileName.Length - 3);
                    switch (strfileExtn)
                    {
                        case "bmp":
                            curBitmap.Save(fileName, ImageFormat.Bmp);
                            break;
                        case "jpg":
                            curBitmap.Save(fileName, ImageFormat.Jpeg);
                            break;
                        default:
                            break;
                    }
                }
            }
            else
                MessageBox.Show("没有要保存的图片", "信息提示");
        }

        //重置
        private void reset_Click(object sender, EventArgs e)
        {
            if (curBitmap != null)
            {
                curBitmap = (Bitmap)Image.FromFile(curFileName);
                this.pictureBox1.Image = curBitmap.Clone() as Image;
            }

            Invalidate();
        }


        ////平移操作
        private void translation_Click(object sender, EventArgs e)
        {
            if (curBitmap != null)
            {
                translation traForm = new translation();
                if (traForm.ShowDialog() == DialogResult.OK)
                {
                    Rectangle rect = new Rectangle(0, 0, curBitmap.Width, curBitmap.Height);
                    BitmapData bitmapData = curBitmap.LockBits(rect, ImageLockMode.ReadWrite, curBitmap.PixelFormat);
                    IntPtr ptr = bitmapData.Scan0;

                    //bytes 的取值关系到数组是否会溢出

                    //像彩色的图片和黑白的不一样，所占的空间大小有区别,所以分开处理

                    ////而且我发现只有黑白线条的图片和黑白图片是不一样的，待求证为什么？？？？
                    if (curBitmap.PixelFormat == PixelFormat.Format24bppRgb)
                    {
                        int bytes = bitmapData.Stride * bitmapData.Height;
                        byte[] grayValues = new byte[bytes];
                        Marshal.Copy(ptr, grayValues, 0, bytes);

                        int x = Convert.ToInt32(traForm.GetXOffset);
                        int y = Convert.ToInt32(traForm.GetYOffset);

                        byte[] tempArray = new byte[bytes];
                        for (int i = 0; i < bytes; i++)
                        {
                            //临时数组初始化为白色（255）像素
                            tempArray[i] = 255;
                        }

                        //平移计算公式
                        for (int i = 0; i < curBitmap.Height; i++)
                        {
                            if ((i + y) < curBitmap.Height && (i + y) > 0)
                            {
                                for (int j = 0; j < curBitmap.Width * 3; j += 3)
                                {
                                    if ((j + x * 3) < curBitmap.Width * 3 && (j + x * 3) > 0)
                                    {
                                        tempArray[(j + x * 3) + 0 + (i + y) * bitmapData.Stride] = grayValues[j + 0 + i * bitmapData.Stride];
                                        tempArray[j + x * 3 + 1 + (i + y) * bitmapData.Stride] = grayValues[j + 1 + i * bitmapData.Stride];
                                        tempArray[j + x * 3 + 2 + (i + y) * bitmapData.Stride] = grayValues[j + 2 + i * bitmapData.Stride];
                                    }
                                }
                            }
                        }

                        grayValues = (byte[])tempArray.Clone();
                        Marshal.Copy(grayValues, 0, ptr, bytes);
                        curBitmap.UnlockBits(bitmapData);
                    }
                    else if (curBitmap.PixelFormat == PixelFormat.Format8bppIndexed)
                    {
                        int bytes = curBitmap.Width * curBitmap.Height;
                        byte[] grayValues = new byte[bytes];
                        Marshal.Copy(ptr, grayValues, 0, bytes);

                        int x = Convert.ToInt32(traForm.GetXOffset);
                        int y = Convert.ToInt32(traForm.GetYOffset);

                        byte[] tempArray = new byte[bytes];
                        for (int i = 0; i < bytes; i++)
                        {
                            tempArray[i] = 255;
                        }

                        for (int i = 0; i < curBitmap.Height; i++)
                        {
                            if ((i + y) < curBitmap.Height && (i + y) > 0)
                            {
                                for (int j = 0; j < curBitmap.Width; j++)
                                {
                                    if ((j + x) < curBitmap.Width && (j + x) > 0)
                                    {
                                        tempArray[(j + x) + (i + y) * bitmapData.Width] = grayValues[j + i * bitmapData.Width];
                                    }
                                }
                            }
                        }
                        grayValues = (byte[])tempArray.Clone();
                        Marshal.Copy(grayValues, 0, ptr, bytes);
                        curBitmap.UnlockBits(bitmapData);
                    }


                }
            }
            else
                MessageBox.Show("没有可移动的图像", "信息提示");

            this.pictureBox1.Image = curBitmap;

            Invalidate();
        }


        ////图像镜像操作
        private void acoustic_pic_Click(object sender, EventArgs e)
        {
            if (curBitmap != null)
            {
                mirror mirForm = new mirror();
                if (mirForm.ShowDialog() == DialogResult.OK)
                {
                    Rectangle rect = new Rectangle(0, 0, curBitmap.Width, curBitmap.Height);
                    BitmapData bmpData = curBitmap.LockBits(rect, ImageLockMode.ReadWrite, curBitmap.PixelFormat);
                    IntPtr ptr = bmpData.Scan0;
                    int bytes = 0;
                    //判断是灰度色图像还是彩色图像，给相应的大小
                    if (curBitmap.PixelFormat == PixelFormat.Format8bppIndexed)//灰度图像
                    {
                        bytes = curBitmap.Width * curBitmap.Height;
                    }
                    else if (curBitmap.PixelFormat == PixelFormat.Format24bppRgb)//彩色图片的编码（包含黑白图片）
                    {
                        bytes = bmpData.Stride * bmpData.Height;
                        // bytes = curBitmap.Width * curBitmap.Height ;
                    }
                    byte[] pixelValues = new byte[bytes];
                    Marshal.Copy(ptr, pixelValues, 0, bytes);

                    byte temp;
                    byte temp1;
                    byte temp2;
                    byte temp3;


                    if (curBitmap.PixelFormat == PixelFormat.Format8bppIndexed)
                    {
                        int halfWidth = curBitmap.Width / 2;
                        //垂直中轴
                        int halfHeight = curBitmap.Height / 2;
                        if (mirForm.GetMirror)
                        {
                            for (int i = 0; i < curBitmap.Height; i++)
                                for (int j = 0; j < halfWidth; j++)
                                {
                                    temp = pixelValues[i * curBitmap.Width + j];
                                    pixelValues[i * curBitmap.Width + j] = pixelValues[(i + 1) * curBitmap.Width - j - 1];
                                    pixelValues[(i + 1) * curBitmap.Width - j - 1] = temp;
                                }
                        }
                        else
                        {
                            for (int j = 0; j < curBitmap.Width; j++)
                                for (int i = 0; i < halfHeight; i++)
                                {
                                    temp = pixelValues[i * curBitmap.Width + j];
                                    pixelValues[i * curBitmap.Width + j] = pixelValues[(curBitmap.Height - i - 1) * curBitmap.Width + j];
                                    pixelValues[(curBitmap.Height - i - 1) * curBitmap.Width + j] = temp;
                                }
                        }
                    }
                    else if (curBitmap.PixelFormat == PixelFormat.Format24bppRgb)
                    {
                        int halfHeight;
                        if (!mirForm.GetMirror)
                        {
                            //垂直镜像处理  
                            switch (bmpData.Height % 2)
                            {
                                case 0: halfHeight = bmpData.Height / 2; break;
                                default: halfHeight = (bmpData.Height + 1) / 2; break;
                            }
                            for (int i = 0; i < bmpData.Width; i++)
                            {
                                for (int j = 0; j < halfHeight; j++)
                                {
                                    int a1 = bmpData.Stride * (bmpData.Height - 1) + 6 * i - bmpData.Stride * j - 3 * i;
                                    int b1 = bmpData.Stride * j + 3 * i;
                                    temp1 = pixelValues[a1];
                                    pixelValues[a1] = pixelValues[b1];
                                    pixelValues[b1] = temp1;
                                    int a2 = a1 + 1;
                                    int b2 = b1 + 1;
                                    temp2 = pixelValues[a2];
                                    pixelValues[a2] = pixelValues[b2];
                                    pixelValues[b2] = temp2;
                                    int a3 = a2 + 1;
                                    int b3 = b2 + 1;
                                    temp3 = pixelValues[a3];
                                    pixelValues[a3] = pixelValues[b3];
                                    pixelValues[b3] = temp3;
                                }
                            }
                        }
                    }

                    Marshal.Copy(pixelValues, 0, ptr, bytes);
                    curBitmap.UnlockBits(bmpData);
                    if (mirForm.GetMirror && curBitmap.PixelFormat != PixelFormat.Format8bppIndexed)
                    {
                        //水平镜像处理 
                        curBitmap.RotateFlip(RotateFlipType.Rotate180FlipY);
                    }
                    this.pictureBox1.Image = curBitmap;
                }

            }
            else
            {
                MessageBox.Show("没有可操作的图像", "信息提示");
            }



            Invalidate();

        }

        ////实现两个byte数组的交换
        private void swap(ref byte v1, ref byte v2)
        {
            byte temp = v1;
            v1 = v2;
            v2 = temp;
        }


        ////图像放缩
        private void scale_Click(object sender, EventArgs e)
        {
            if (curBitmap != null)
            {
                zoom zoomForm = new zoom();
                if (zoomForm.ShowDialog() == DialogResult.OK)
                {
                    Rectangle rect = new Rectangle(0, 0, curBitmap.Width, curBitmap.Height);
                    BitmapData bmpData = curBitmap.LockBits(rect, ImageLockMode.ReadWrite, curBitmap.PixelFormat);
                    IntPtr ptr = bmpData.Scan0;
                    int bytes = curBitmap.Width * curBitmap.Height;
                    byte[] grayValues = new byte[bytes];
                    Marshal.Copy(ptr, grayValues, 0, bytes);

                    //得到横向和纵向缩放量
                    double x = Convert.ToDouble(zoomForm.GetXZoom);
                    double y = Convert.ToDouble(zoomForm.GetYZoom);

                    //图像的几何中心
                    int halfWidth = (int)(curBitmap.Width / 2);
                    int halfHeight = (int)(curBitmap.Height / 2);

                    int xz = 0;
                    int yz = 0;
                    int tempWidth = 0;
                    int tempHeight = 0;

                    byte[] tempArray = new byte[bytes];

                    if (zoomForm.GetNearOrBil == true)
                    {
                        //最近邻插值法
                        for (int i = 0; i < curBitmap.Height; i++)
                        {
                            for (int j = 0; j < curBitmap.Width; j++)
                            {
                                //以图像的几何中心为坐标原点进行坐标变换
                                //按逆向映射得到输入图像的坐标
                                tempHeight = i - halfHeight;
                                tempWidth = j - halfWidth;//以图像的几何中心为坐标原点的横坐标

                                //在不同象限进行四舍五入处理
                                if (tempWidth > 0)
                                {
                                    //进行缩放
                                    xz = (int)(tempWidth / x + 0.5);
                                }
                                else
                                {//tempWidth < 0 ,则-0.5才能四舍五入
                                    xz = (int)(tempWidth / x - 0.5);
                                }
                                if (tempHeight > 0)
                                {
                                    yz = (int)(tempHeight / y + 0.5);
                                }
                                else
                                {
                                    yz = (int)(tempHeight / y - 0.5);
                                }

                                //坐标逆变换（坐标原点变回原来的（0,0）点了）
                                //经过缩放的坐标，映射到原来以（0,0）点为坐标原点的坐标系上
                                tempWidth = xz + halfWidth;
                                tempHeight = yz + halfHeight;
                                //得到输出图像像素值
                                if (tempWidth < 0 || tempWidth >= curBitmap.Width || tempHeight < 0 || tempHeight >= curBitmap.Height)
                                {
                                    //缩放后留下的空白部分用白色像素代替
                                    tempArray[i * curBitmap.Width + j] = 255;
                                }
                                else
                                {
                                    //tempArray[i * curBitmap.Width + j]是缩放后的坐标
                                    //grayValues[tempHeight * curBitmap.Width + tempWidth]是缩放后对应的原图像素坐标
                                    tempArray[i * curBitmap.Width + j] = grayValues[tempHeight * curBitmap.Width + tempWidth];
                                }
                            }
                        }
                    }
                    else
                    {
                        //双线性插值法
                        double tempX, tempY, p, q;
                        for (int i = 0; i < curBitmap.Height; i++)
                        {
                            for (int j = 0; j < curBitmap.Width; j++)
                            {
                                //以图像的几何中心为坐标原点进行坐标变换
                                //按逆向映射得到输入图像的坐标
                                tempHeight = i - halfHeight;
                                tempWidth = j - halfWidth;
                                tempX = tempWidth / x;
                                tempY = tempHeight / y;

                                //在不同象限进行四舍五入处理
                                if (tempWidth > 0)
                                {
                                    //进行缩放
                                    xz = (int)tempX;
                                }
                                else
                                {
                                    xz = (int)(tempX - 1);
                                }
                                if (tempHeight > 0)
                                {
                                    yz = (int)tempY;
                                }
                                else
                                {
                                    yz = (int)(tempY - 1);
                                }

                                //f(i+p,j+q)=(1-p)(1-q)f(i,j)+(1-p)qf(i,j+1)+p(1-q)f(i+1,j)+pqf(i+1, j + 1)
                                //得到公式中的p和q
                                p = tempX - xz;
                                q = tempY - yz;

                                //坐标逆变换
                                tempWidth = xz + halfWidth;
                                tempHeight = yz + halfHeight;
                                if (tempWidth < 0 || (tempWidth + 1) >= curBitmap.Width || tempHeight < 0 || (tempHeight + 1) >= curBitmap.Height)
                                {
                                    //缩放后留下的空白部分用白色像素代替
                                    tempArray[i * curBitmap.Width + j] = 255;
                                }
                                else
                                {
                                    //应用公式得到双线性插值
                                    tempArray[i * curBitmap.Width + j] = (byte)((1.0 - q) * ((1.0 - p) * grayValues[tempHeight * curBitmap.Width + tempWidth] + p * grayValues[tempHeight * curBitmap.Width + tempWidth + 1]) +
                                        q * ((1.0 - p) * grayValues[(tempHeight + 1) * curBitmap.Width + tempWidth] + p * grayValues[(tempHeight + 1) * curBitmap.Width + 1 + tempWidth]));
                                }
                            }
                        }

                    }

                    grayValues = (byte[])tempArray.Clone();

                    Marshal.Copy(grayValues, 0, ptr, bytes);
                    curBitmap.UnlockBits(bmpData);
                }

                this.pictureBox1.Image = curBitmap;
            }
            else
            {
                MessageBox.Show("没有可处理的图片", "信息提示");
            }

            Invalidate();
        }

        ////图像旋转
        private void revolve_Click(object sender, EventArgs e)
        {
            if (curBitmap != null)
            {
                rotation rotationFrom = new rotation();
                if (rotationFrom.ShowDialog() == DialogResult.OK)
                {
                    double degree = Convert.ToDouble(rotationFrom.GetDegree);
                    if (rotationHelp.Rotation(curBitmap, degree, out dstmap))
                    {
                        this.pictureBox1.Image = dstmap.Clone() as Image;
                    }
                }
            }
            else
            {
                MessageBox.Show("没有可处理的图片", "信息提示");
            }
            Invalidate();
        }

        ////伪彩色处理
        private void pseudo_color_Click(object sender, EventArgs e)
        {
            if (curBitmap != null)
            {
                if (curBitmap.PixelFormat == PixelFormat.Format8bppIndexed)
                {
                    pColor pc = new pColor();
                    if (pc.ShowDialog() == DialogResult.OK)
                    {
                        Rectangle rect = new Rectangle(0, 0, curBitmap.Width, curBitmap.Height);
                        BitmapData bmpData = curBitmap.LockBits(rect, ImageLockMode.ReadWrite, curBitmap.PixelFormat);
                        IntPtr ptr = bmpData.Scan0;
                        int bytes = curBitmap.Width * curBitmap.Height;
                        byte[] grayValues = new byte[bytes];
                        Marshal.Copy(ptr, grayValues, 0, bytes);

                        //得到用哪种方法进行伪彩色处理
                        bool method = pc.GetMethod;
                        //得到分层数
                        byte seg = pc.GetSeg;
                        byte[] rgbValues = new byte[bytes * 3];
                        Array.Clear(rgbValues, 0, bytes * 3);
                        byte tempB;
                        if (method == false)
                        {
                            for (int i = 0; i < bytes; i++)
                            {
                                byte ser = (byte)(256 / seg);
                                tempB = (byte)(grayValues[i] / ser);
                                rgbValues[i * 3 + 1] = (byte)(tempB * ser);
                                rgbValues[i * 3] = (byte)((seg - 1 - tempB) * ser);

                            }
                        }
                        else
                        {
                            for (int i = 0; i < bytes; i++)
                            {
                                if (grayValues[i] < 64)
                                {
                                    rgbValues[i * 3 + 2] = 0;
                                    rgbValues[i * 3 + 1] = (byte)(4 * grayValues[i]);
                                    rgbValues[i * 3] = 255;
                                }
                                else if (grayValues[i] < 128)
                                {
                                    rgbValues[i * 3 + 2] = 0;
                                    rgbValues[i * 3 + 1] = 255;
                                    rgbValues[i * 3] = (byte)(-4 * grayValues[i] + 2 * 255);
                                }
                                else if (grayValues[i] < 192)
                                {
                                    rgbValues[i * 3 + 2] = (byte)(4 * grayValues[i] - 2 * 255);
                                    rgbValues[i * 3 + 1] = 255;
                                    rgbValues[i * 3] = 0;
                                }
                                else
                                {
                                    rgbValues[i * 3 + 2] = 255;
                                    rgbValues[i * 3 + 1] = (byte)(-4 * grayValues[i] + 4 * 255);
                                    rgbValues[i * 3] = 0;
                                }
                            }
                        }

                        curBitmap = new Bitmap(curBitmap.Width, curBitmap.Height, PixelFormat.Format24bppRgb);
                        bmpData = curBitmap.LockBits(rect, ImageLockMode.ReadWrite, curBitmap.PixelFormat);
                        ptr = bmpData.Scan0;
                        Marshal.Copy(rgbValues, 0, ptr, bytes * 3);
                        curBitmap.UnlockBits(bmpData);

                        this.pictureBox1.Image = curBitmap.Clone() as Image;
                    }
                }
                else
                {
                    MessageBox.Show("伪彩色处理只针对灰度图像", "信息提示");
                }

            }
            else
            {
                MessageBox.Show("没有可处理的图片", "信息提示");
            }
            Invalidate();
        }

        ////彩色图像平滑处理
        private void smooth_Click(object sender, EventArgs e)
        {
            if (curBitmap != null)
            {
                smoothColor smoothC = new smoothColor();
                if (smoothC.ShowDialog() == DialogResult.OK)
                {
                    Rectangle rect = new Rectangle(0, 0, curBitmap.Width, curBitmap.Height);
                    BitmapData bmpData = curBitmap.LockBits(rect, ImageLockMode.ReadWrite, curBitmap.PixelFormat);
                    IntPtr ptr = bmpData.Scan0;
                    int bytes = curBitmap.Width * curBitmap.Height;
                    byte[] rgbValues = new byte[bytes * 3];
                    Marshal.Copy(ptr, rgbValues, 0, bytes * 3);

                    bool method = smoothC.GetMethod;
                    byte sideL = smoothC.GetLength;

                    if (method)
                    {
                        byte[] rValues = new byte[bytes];
                        byte[] gValues = new byte[bytes];
                        byte[] bValues = new byte[bytes];

                        for (int i = 0; i < bytes; i++)
                        {
                            rValues[i] = rgbValues[i * 3 + 2];
                            gValues[i] = rgbValues[i * 3 + 1];
                            bValues[i] = rgbValues[i * 3];
                        }

                        rValues = Smooth(rValues, sideL);
                        gValues = Smooth(gValues, sideL);
                        bValues = Smooth(bValues, sideL);

                        for (int i = 0; i < bytes; i++)
                        {
                            rgbValues[i * 3 + 2] = rValues[i];
                            rgbValues[i * 3 + 1] = gValues[i];
                            rgbValues[i * 3] = bValues[i];
                        }
                    }

                    Marshal.Copy(rgbValues, 0, ptr, bytes * 3);
                    curBitmap.UnlockBits(bmpData);
                    this.pictureBox1.Image = curBitmap.Clone() as Image;
                }

                Invalidate();
            }
            else
                MessageBox.Show("没有可处理的图片", "信息提示");

        }

        ////彩色图像平滑处理函数
        private byte[] Smooth(byte[] comValues, byte sideLength)
        {
            byte halfLength = (byte)(sideLength / 2);
            byte[] comS = new byte[comValues.Length];
            comS = (byte[])comValues.Clone();
            byte[] comD = new byte[comS.Length];
            Array.Clear(comD, 0, comD.Length);

            switch (sideLength)
            {
                case 3:
                    for (int i = 0; i < curBitmap.Height; i++)
                    {
                        for (int j = 0; j < curBitmap.Width; j++)
                        {
                            comD[i * curBitmap.Width + j] = (byte)((comS[i * curBitmap.Width + j] +
                                comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] +
                                comS[((i + 1) % curBitmap.Height) * curBitmap.Width + j] +
                                comS[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                comS[i * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] +
                                comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] +
                                comS[((i + 1) % curBitmap.Height) * curBitmap.Width + ((Math.Abs(j - 1)) % curBitmap.Width)] +
                                comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                comS[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)]) / 9);
                        }
                    }
                    break;

                case 5:
                    for (int i = 0; i < curBitmap.Height; i++)
                    {
                        for (int j = 0; j < curBitmap.Width; j++)
                        {
                            comD[i * curBitmap.Width + j] = (byte)((comS[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2)) % curBitmap.Width] +
                                comS[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] +
                                comS[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + j] +
                                comS[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                comS[((Math.Abs(i - 2)) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)] +
                                comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] +
                                comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] +
                                comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + j] +
                                comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Height)] +
                                comS[((Math.Abs(i - 1)) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Height)] +
                                comS[i * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] +
                                comS[i * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] +
                                comS[i * curBitmap.Width + j] +
                                comS[i * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                comS[i * curBitmap.Width + ((j + 2) % curBitmap.Width)] +
                                comS[((i + 2) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] +
                                comS[((i + 2) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] +
                                comS[((i + 2) % curBitmap.Height) * curBitmap.Width + j] +
                                comS[((i + 2) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                comS[((i + 2) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)] +
                                comS[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 2) % curBitmap.Width)] +
                                comS[((i + 1) % curBitmap.Height) * curBitmap.Width + (Math.Abs(j - 1) % curBitmap.Width)] +
                                comS[((i + 1) % curBitmap.Height) * curBitmap.Width + j] +
                                comS[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 1) % curBitmap.Width)] +
                                comS[((i + 1) % curBitmap.Height) * curBitmap.Width + ((j + 2) % curBitmap.Width)]) / 25);
                        }
                    }
                    break;
                default:
                    break;
            }
            return comD;
        }

        ////彩色图像锐化处理
        private void sharpening_Click(object sender, EventArgs e)
        {
            if (curBitmap != null)
            {
                this.pictureBox1.Image = sharp(curBitmap);
                Invalidate();
            }
            else
                MessageBox.Show("没有可处理的图片", "信息提示");
        }

        //拉普拉斯锐化处理算法
        private Image sharp(Bitmap bmp)
        {
            int height = bmp.Height;
            int width = bmp.Width;
            Bitmap newbmp = new Bitmap(width, height);

            LockBitmap lbmp = new LockBitmap(bmp);
            LockBitmap newlbmp = new LockBitmap(newbmp);
            lbmp.LockBits();
            newlbmp.LockBits();

            Color pixel;
            //拉普拉斯模板
            int[] Laplacian = { -1, -1, -1, -1, 9, -1, -1, -1, -1 };
            for (int x = 1; x < width - 1; x++)
            {
                for (int y = 1; y < height - 1; y++)
                {
                    int r = 0, g = 0, b = 0;
                    int Index = 0;
                    for (int col = -1; col <= 1; col++)
                    {
                        for (int row = -1; row <= 1; row++)
                        {
                            pixel = lbmp.GetPixel(x + row, y + col); r += pixel.R * Laplacian[Index];
                            g += pixel.G * Laplacian[Index];
                            b += pixel.B * Laplacian[Index];
                            Index++;
                        }
                    }
                    //处理颜色值溢出
                    r = r > 255 ? 255 : r;
                    r = r < 0 ? 0 : r;
                    g = g > 255 ? 255 : g;
                    g = g < 0 ? 0 : g;
                    b = b > 255 ? 255 : b;
                    b = b < 0 ? 0 : b;
                    newlbmp.SetPixel(x - 1, y - 1, Color.FromArgb(r, g, b));
                }
            }
            lbmp.UnlockBits();
            newlbmp.UnlockBits();
            return newbmp;
        }

        ////边缘检测操作
        private void Roberts算子_Click(object sender, EventArgs e)
        {
            if (curBitmap != null)
            {
                Bitmap myimage = null;
                Edge(curBitmap, "Roberts", out myimage);
                this.pictureBox1.Image = myimage;
            }
            else
                MessageBox.Show("没有可处理的图片", "信息提示");
        }

        private void Perwit算子_Click(object sender, EventArgs e)
        {
            if (curBitmap != null)
            {
                Bitmap myimage = null;
                Edge(curBitmap, "Prewitt", out myimage);
                this.pictureBox1.Image = myimage;
            }
            else
                MessageBox.Show("没有可处理的图片", "信息提示");
        }

        private void Sobel算子_Click(object sender, EventArgs e)
        {
            if (curBitmap != null)
            {
                Bitmap myimage = null;
                Edge(curBitmap, "Sobel", out myimage);
                this.pictureBox1.Image = myimage;
            }
            else
                MessageBox.Show("没有可处理的图片", "信息提示");
        }

        ////边缘检测算法
        private static bool Edge(Bitmap srcBmp, String edgeDetectors, out Bitmap dstBmp, int[] mask = null, int T = 0)
        {
            if (srcBmp == null)
            {
                dstBmp = null;
                return false;
            }
            int[] template = new int[25];
            if (mask != null) { template = mask; }
            Bitmap tempSrcBmp = new Bitmap(srcBmp);//为形态学边缘检测所用  
            dstBmp = new Bitmap(srcBmp);
            BitmapData bmpDataSrc = srcBmp.LockBits(new Rectangle(0, 0, srcBmp.Width, srcBmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);
            BitmapData bmpDataDst = dstBmp.LockBits(new Rectangle(0, 0, dstBmp.Width, dstBmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);
            //double[] laplacianArray = new double[bmpDataSrc.Stride * bmpDataSrc.Height];//存储拉普拉斯算子中间结果   
            unsafe
            {
                byte* ptrSrc = (byte*)bmpDataSrc.Scan0;
                byte* ptrDst = (byte*)bmpDataDst.Scan0;
                double gradX, gradY, grad;
                switch (edgeDetectors)
                {
                    case "Roberts"://Roberts算子  
                        for (int i = 0; i < srcBmp.Height; i++)
                        {
                            for (int j = 0; j < srcBmp.Width; j++)
                            {
                                gradX = ptrSrc[i * bmpDataSrc.Stride + j * 3] - ptrSrc[(i + 1) % srcBmp.Height * bmpDataSrc.Stride + (j + 1) % srcBmp.Width * 3];
                                gradY = ptrSrc[i * bmpDataSrc.Stride + (j + 1) % srcBmp.Width * 3] - ptrSrc[(i + 1) % srcBmp.Height * bmpDataSrc.Stride + j * 3];
                                grad = Math.Sqrt(gradX * gradX + gradY * gradY);
                                grad = grad > 255 ? 255 : grad;
                                ptrDst[i * bmpDataDst.Stride + j * 3] = ptrDst[i * bmpDataDst.Stride + j * 3 + 1] = ptrDst[i * bmpDataDst.Stride + j * 3 + 2] = (byte)grad;
                            }
                        }
                        break;
                    case "Prewitt"://prewitt算子  
                        for (int i = 0; i < srcBmp.Height; i++)
                        {
                            for (int j = 0; j < srcBmp.Width; j++)
                            {
                                gradX = ptrSrc[Math.Abs(i - 1) % srcBmp.Height * bmpDataSrc.Stride + (j + 1) % srcBmp.Width * 3] +
                                        ptrSrc[i * bmpDataSrc.Stride + (j + 1) % srcBmp.Width * 3] +
                                        ptrSrc[(i + 1) % srcBmp.Height * bmpDataSrc.Stride + (j + 1) % srcBmp.Width * 3] -
                                        ptrSrc[Math.Abs(i - 1) % srcBmp.Height * bmpDataSrc.Stride + Math.Abs(j - 1) % srcBmp.Width * 3] -
                                        ptrSrc[i * bmpDataSrc.Stride + Math.Abs(j - 1) % srcBmp.Width * 3] -
                                        ptrSrc[(i + 1) % srcBmp.Height * bmpDataSrc.Stride + Math.Abs(j - 1) % srcBmp.Width * 3];
                                gradY = ptrSrc[Math.Abs(i - 1) % srcBmp.Height * bmpDataSrc.Stride + Math.Abs(j - 1) % srcBmp.Width * 3] +
                                        ptrSrc[Math.Abs(i - 1) % srcBmp.Height * bmpDataSrc.Stride + j * 3] +
                                        ptrSrc[Math.Abs(i - 1) % srcBmp.Height * bmpDataSrc.Stride + (j + 1) % srcBmp.Width * 3] -
                                        ptrSrc[(i + 1) % srcBmp.Height * bmpDataSrc.Stride + Math.Abs(j - 1) % srcBmp.Width * 3] -
                                        ptrSrc[(i + 1) % srcBmp.Height * bmpDataSrc.Stride + j * 3] -
                                        ptrSrc[(i + 1) % srcBmp.Height * bmpDataSrc.Stride + (j + 1) % srcBmp.Width * 3];
                                grad = Math.Sqrt(gradX * gradX + gradY * gradY);
                                grad = grad > 255 ? 255 : grad;
                                ptrDst[i * bmpDataDst.Stride + j * 3] = ptrDst[i * bmpDataDst.Stride + j * 3 + 1] = ptrDst[i * bmpDataDst.Stride + j * 3 + 2] = (byte)grad;
                            }
                        }
                        break;
                    case "Sobel"://solbel算子  
                        for (int i = 0; i < srcBmp.Height; i++)
                        {
                            for (int j = 0; j < srcBmp.Width; j++)
                            {
                                gradX = ptrSrc[Math.Abs(i - 1) % srcBmp.Height * bmpDataSrc.Stride + (j + 1) % srcBmp.Width * 3] +
                                        2 * ptrSrc[i * bmpDataSrc.Stride + (j + 1) % srcBmp.Width * 3] +
                                        ptrSrc[(i + 1) % srcBmp.Height * bmpDataSrc.Stride + (j + 1) % srcBmp.Width * 3] -
                                        ptrSrc[Math.Abs(i - 1) % srcBmp.Height * bmpDataSrc.Stride + Math.Abs(j - 1) % srcBmp.Width * 3] -
                                        2 * ptrSrc[i * bmpDataSrc.Stride + Math.Abs(j - 1) % srcBmp.Width * 3] -
                                        ptrSrc[(i + 1) % srcBmp.Height * bmpDataSrc.Stride + Math.Abs(j - 1) % srcBmp.Width * 3];
                                gradY = ptrSrc[Math.Abs(i - 1) % srcBmp.Height * bmpDataSrc.Stride + Math.Abs(j - 1) % srcBmp.Width * 3] +
                                        2 * ptrSrc[Math.Abs(i - 1) % srcBmp.Height * bmpDataSrc.Stride + j * 3] +
                                        ptrSrc[Math.Abs(i - 1) % srcBmp.Height * bmpDataSrc.Stride + (j + 1) % srcBmp.Width * 3] -
                                        ptrSrc[(i + 1) % srcBmp.Height * bmpDataSrc.Stride + Math.Abs(j - 1) % srcBmp.Width * 3] -
                                        2 * ptrSrc[(i + 1) % srcBmp.Height * bmpDataSrc.Stride + j * 3] -
                                        ptrSrc[(i + 1) % srcBmp.Height * bmpDataSrc.Stride + (j + 1) % srcBmp.Width * 3];
                                grad = Math.Sqrt(gradX * gradX + gradY * gradY);
                                grad = grad > 255 ? 255 : grad;
                                ptrDst[i * bmpDataDst.Stride + j * 3] = ptrDst[i * bmpDataDst.Stride + j * 3 + 1] = ptrDst[i * bmpDataDst.Stride + j * 3 + 2] = (byte)grad;
                            }
                        }
                        break;
                    default:
                        break;
                }
            }
            srcBmp.UnlockBits(bmpDataSrc);
            dstBmp.UnlockBits(bmpDataDst);

            return true;
        }

        private void apart_Click(object sender, EventArgs e)
        {
            if (curBitmap != null)
            {
                segColor seg = new segColor();
                if (seg.ShowDialog() == DialogResult.OK)
                {
                    Rectangle rect = new Rectangle(0, 0, curBitmap.Width, curBitmap.Height);
                    BitmapData bmpData = curBitmap.LockBits(rect, ImageLockMode.ReadWrite, curBitmap.PixelFormat);
                    IntPtr ptr = bmpData.Scan0;
                    int bytes = curBitmap.Width * curBitmap.Height;
                    byte[] rgbValues = new byte[bytes * 3];
                    Marshal.Copy(ptr, rgbValues, 0, bytes * 3);

                    byte numbers = seg.GetNum;

                    int[] kNum = new int[numbers];
                    int[] kAver = new int[numbers * 3];
                    int[] kOldAver = new int[numbers * 3];
                    int[] kSum = new int[numbers * 3];
                    double[] kTemp = new double[numbers];
                    byte[] segmentMap = new byte[bytes * 3];

                    for (int i = 0; i < numbers; i++)
                    {
                        kAver[i * 3 + 2] = kOldAver[i * 3 + 2] = Convert.ToInt16(i * 255 / (numbers - 1));
                        kAver[i * 3 + 1] = kOldAver[i * 3 + 1] = Convert.ToInt16(i * 255 / (numbers - 1));
                        kAver[i * 3] = kOldAver[i * 3] = Convert.ToInt16(i * 255 / (numbers - 1));
                    }
                    int count = 0;
                    while (true)
                    {
                        int order = 0;
                        for (int i = 0; i < numbers; i++)
                        {
                            kNum[i] = 0;
                            kSum[i * 3 + 2] = kSum[i * 3 + 1] = kSum[i * 3] = 0;
                            kAver[i * 3 + 2] = kOldAver[i * 3 + 2];
                            kAver[i * 3 + 1] = kOldAver[i * 3 + 1];
                            kAver[i * 3] = kOldAver[i * 3];

                        }

                        for (int i = 0; i < bytes; i++)
                        {
                            for (int j = 0; j < numbers; j++)
                            {
                                kTemp[j] = Math.Pow(rgbValues[i * 3 + 2] - kAver[j * 3 + 2], 2) +
                                    Math.Pow(rgbValues[i * 3 + 1] - kAver[j * 3 + 1], 2) +
                                    Math.Pow(rgbValues[i * 3] - kAver[j * 3], 2);
                            }
                            double temp = 1000000;
                            for (int j = 0; j < numbers; j++)
                            {
                                if (kTemp[j] < temp)
                                {
                                    temp = kTemp[j];
                                    order = j;
                                }
                            }
                            kNum[order]++;
                            kSum[order * 3 + 2] += rgbValues[i * 3 + 2];
                            kSum[order * 3 + 1] += rgbValues[i * 3 + 1];
                            kSum[order * 3] += rgbValues[i * 3];
                            segmentMap[i] = Convert.ToByte(order);
                        }

                        for (int i = 0; i < numbers; i++)
                        {
                            if (kNum[i] != 0)
                            {
                                kOldAver[i * 3 + 2] = Convert.ToInt16(kSum[i * 3 + 2] / kNum[i]);
                                kOldAver[i * 3 + 1] = Convert.ToInt16(kSum[i * 3 + 1] / kNum[i]);
                                kOldAver[i * 3] = Convert.ToInt16(kSum[i * 3] / kNum[i]);
                            }
                        }

                        int kkk = 0;
                        count++;
                        for (int i = 0; i < numbers; i++)
                        {
                            if (kAver[i * 3 + 2] == kOldAver[i * 3 + 2] &&
                                kAver[i * 3 + 1] == kOldAver[i * 3 + 1] &&
                                kAver[i * 3] == kOldAver[i * 3])
                            {
                                kkk++;
                            }
                        }
                        if (kkk == numbers || count == 100)
                            break;
                    }

                    for (int i = 0; i < bytes; i++)
                    {
                        for (int j = 0; j < numbers; j++)
                        {
                            if (segmentMap[i] == j)
                            {
                                rgbValues[i * 3 + 2] = Convert.ToByte(kAver[j * 3 + 2]);
                                rgbValues[i * 3 + 1] = Convert.ToByte(kAver[j * 3 + 1]);
                                rgbValues[i * 3] = Convert.ToByte(kAver[j * 3]);
                            }
                        }
                    }

                    Marshal.Copy(rgbValues, 0, ptr, bytes * 3);
                    curBitmap.UnlockBits(bmpData);
                    this.pictureBox1.Image = curBitmap.Clone() as Image;
                }
                Invalidate();
            }
            else
                MessageBox.Show("没有可处理的图片", "信息提示");
        }
    }

    ////针对彩色图像处理时所用的类和方法
    public class LockBitmap
    {
        Bitmap source = null;
        IntPtr Iptr = IntPtr.Zero;
        BitmapData bitmapData = null;

        public byte[] Pixels { get; set; }
        public int Depth { get; private set; }
        public int Width { get; private set; }
        public int Height { get; private set; }

        public LockBitmap(Bitmap source)
        {
            this.source = source;
        }

        /// <summary>
        /// Lock bitmap data
        /// </summary>
        public void LockBits()
        {
            try
            {
                // Get width and height of bitmap
                Width = source.Width;
                Height = source.Height;

                // get total locked pixels count
                int PixelCount = Width * Height;

                // Create rectangle to lock
                Rectangle rect = new Rectangle(0, 0, Width, Height);

                // get source bitmap pixel format size
                Depth = System.Drawing.Bitmap.GetPixelFormatSize(source.PixelFormat);

                // Check if bpp (Bits Per Pixel) is 8, 24, or 32
                if (Depth != 8 && Depth != 24 && Depth != 32)
                {
                    throw new ArgumentException("Only 8, 24 and 32 bpp images are supported.");
                }

                // Lock bitmap and return bitmap data
                bitmapData = source.LockBits(rect, ImageLockMode.ReadWrite,
                                             source.PixelFormat);

                // create byte array to copy pixel values
                int step = Depth / 8;
                Pixels = new byte[PixelCount * step];
                Iptr = bitmapData.Scan0;

                // Copy data from pointer to array
                Marshal.Copy(Iptr, Pixels, 0, Pixels.Length);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UnlockBits()
        {
            try
            {
                // Copy data from byte array to pointer
                Marshal.Copy(Pixels, 0, Iptr, Pixels.Length);

                // Unlock bitmap data
                source.UnlockBits(bitmapData);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get the color of the specified pixel
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public Color GetPixel(int x, int y)
        {
            Color clr = Color.Empty;

            // Get color components count
            int cCount = Depth / 8;

            // Get start index of the specified pixel
            int i = ((y * Width) + x) * cCount;

            if (i > Pixels.Length - cCount)
                throw new IndexOutOfRangeException();

            if (Depth == 32) // For 32 bpp get Red, Green, Blue and Alpha
            {
                byte b = Pixels[i];
                byte g = Pixels[i + 1];
                byte r = Pixels[i + 2];
                byte a = Pixels[i + 3]; // a
                clr = Color.FromArgb(a, r, g, b);
            }
            if (Depth == 24) // For 24 bpp get Red, Green and Blue
            {
                byte b = Pixels[i];
                byte g = Pixels[i + 1];
                byte r = Pixels[i + 2];
                clr = Color.FromArgb(r, g, b);
            }
            if (Depth == 8)
            // For 8 bpp get color value (Red, Green and Blue values are the same)
            {
                byte c = Pixels[i];
                clr = Color.FromArgb(c, c, c);
            }
            return clr;
        }

        /// <summary>
        /// Set the color of the specified pixel
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="color"></param>
        public void SetPixel(int x, int y, Color color)
        {
            // Get color components count
            int cCount = Depth / 8;

            // Get start index of the specified pixel
            int i = ((y * Width) + x) * cCount;

            if (Depth == 32) // For 32 bpp set Red, Green, Blue and Alpha
            {
                Pixels[i] = color.B;
                Pixels[i + 1] = color.G;
                Pixels[i + 2] = color.R;
                Pixels[i + 3] = color.A;
            }
            if (Depth == 24) // For 24 bpp set Red, Green and Blue
            {
                Pixels[i] = color.B;
                Pixels[i + 1] = color.G;
                Pixels[i + 2] = color.R;
            }
            if (Depth == 8)
            // For 8 bpp set color value (Red, Green and Blue values are the same)
            {
                Pixels[i] = color.B;
            }
        }
    }
}







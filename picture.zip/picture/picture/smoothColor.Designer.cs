﻿namespace picture
{
    partial class smoothColor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.start = new System.Windows.Forms.Button();
            this.close = new System.Windows.Forms.Button();
            this.rgbS = new System.Windows.Forms.RadioButton();
            this.length = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.length)).BeginInit();
            this.SuspendLayout();
            // 
            // start
            // 
            this.start.Location = new System.Drawing.Point(73, 181);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(75, 23);
            this.start.TabIndex = 0;
            this.start.Text = "确定";
            this.start.UseVisualStyleBackColor = true;
            this.start.Click += new System.EventHandler(this.start_Click);
            // 
            // close
            // 
            this.close.Location = new System.Drawing.Point(319, 181);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(75, 23);
            this.close.TabIndex = 1;
            this.close.Text = "退出";
            this.close.UseVisualStyleBackColor = true;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // rgbS
            // 
            this.rgbS.AutoSize = true;
            this.rgbS.Checked = true;
            this.rgbS.Location = new System.Drawing.Point(155, 45);
            this.rgbS.Name = "rgbS";
            this.rgbS.Size = new System.Drawing.Size(113, 16);
            this.rgbS.TabIndex = 2;
            this.rgbS.TabStop = true;
            this.rgbS.Text = "RGB空间平滑处理";
            this.rgbS.UseVisualStyleBackColor = true;
            // 
            // length
            // 
            this.length.Increment = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.length.Location = new System.Drawing.Point(220, 112);
            this.length.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.length.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.length.Name = "length";
            this.length.Size = new System.Drawing.Size(120, 21);
            this.length.TabIndex = 4;
            this.length.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(99, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 12);
            this.label1.TabIndex = 5;
            this.label1.Text = "领域模版边长";
            // 
            // smoothColor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(472, 236);
            this.ControlBox = false;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.length);
            this.Controls.Add(this.rgbS);
            this.Controls.Add(this.close);
            this.Controls.Add(this.start);
            this.Name = "smoothColor";
            this.Text = "s";
            ((System.ComponentModel.ISupportInitialize)(this.length)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button start;
        private System.Windows.Forms.Button close;
        private System.Windows.Forms.RadioButton rgbS;
        private System.Windows.Forms.NumericUpDown length;
        private System.Windows.Forms.Label label1;
    }
}